#!/usr/bin/env python3
greeting = "Welcome to the Brain Games!"
def greet(greeting):
  print(greeting)
def main():
  greet(greeting)
if __name__ == '__main__':
  main()
