### Hexlet tests and linter status:
[![Actions Status](https://github.com/KepiWole/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/KepiWole/python-project-lvl1/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/1dda31fa6421f5e666e6/maintainability)](https://codeclimate.com/github/KepiWole/python-project-lvl1/maintainability)
asciinema brain-even
https://asciinema.org/a/SvPBV4R3NnkTdzp2Pfpyc0AxJ
asciinema brain-calc
 https://asciinema.org/a/0mKpoSjxm8SOoRvovzxDd2sLC
asciinema brain-gcd
https://asciinema.org/a/8N1WrqyHOTy97ZD0TZQba4Jvk
asciinema brain_progression
https://asciinema.org/a/HASp3npmmJLWmg95b7D1BiMDt
asciinema brain_prime
https://asciinema.org/a/pZEvFYQysWyHLVoCFGZh6tYRq
